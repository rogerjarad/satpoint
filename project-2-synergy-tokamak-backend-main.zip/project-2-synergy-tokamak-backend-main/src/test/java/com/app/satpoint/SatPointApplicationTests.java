package com.app.satpoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SatPointApplicationTests {

    @Test
    void contextLoads() {
    }

}
