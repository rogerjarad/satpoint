package com.app.satpoint.models;

public class UserDTO {
    public String username;
    public String password;
}
