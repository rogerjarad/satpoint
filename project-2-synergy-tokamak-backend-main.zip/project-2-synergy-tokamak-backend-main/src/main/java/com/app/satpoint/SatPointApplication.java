package com.app.satpoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SatPointApplication {

    public static void main(String[] args) {
        SpringApplication.run(SatPointApplication.class, args);
    }

}
