// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class Gps.Service.TsService {

//   constructor() { }
// }
