// import { TestBed } from '@angular/core/testing';

// import { Gps.Service.TsService } from './gps.service.ts.service';

// describe('Gps.Service.TsService', () => {
//   let service: Gps.Service.TsService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(Gps.Service.TsService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
