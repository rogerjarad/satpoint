export enum SideNavDirection {
    Left = 'left',
    Right = 'right'
}