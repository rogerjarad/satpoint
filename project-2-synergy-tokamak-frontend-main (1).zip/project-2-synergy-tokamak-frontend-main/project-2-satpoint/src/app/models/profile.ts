export class Update {
    constructor(
        public firstName : String | undefined,
        public lastName : String | undefined,
        public email: String | undefined,
        public aboutMe : String | undefined,
        public latitude: Number | undefined,
        public longitude: Number | undefined

    ){}
}
