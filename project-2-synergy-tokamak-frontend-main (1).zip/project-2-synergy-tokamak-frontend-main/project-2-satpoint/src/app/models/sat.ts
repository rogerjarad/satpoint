export class Sat {
  constructor(
    public satId: number,
    public noradId: string,
    public satName: string,
    public satPicture: string,
    public numFavorites: number,
    public favorite: boolean
  ) {}
}
