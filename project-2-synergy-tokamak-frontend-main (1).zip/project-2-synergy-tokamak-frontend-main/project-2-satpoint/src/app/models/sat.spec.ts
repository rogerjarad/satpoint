import { Sat } from './sat';

describe('Sat', () => {
  it('should create an instance', () => {
    expect(new Sat(1, "space", "","",0)).toBeTruthy();
  });
});
