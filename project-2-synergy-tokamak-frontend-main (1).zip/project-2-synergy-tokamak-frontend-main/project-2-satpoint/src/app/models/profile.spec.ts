import { Update } from "./profile";


describe('Update', () => {
    it('should create an instance', () => {
      expect(new Update()).toBeTruthy();
    });
  });
  